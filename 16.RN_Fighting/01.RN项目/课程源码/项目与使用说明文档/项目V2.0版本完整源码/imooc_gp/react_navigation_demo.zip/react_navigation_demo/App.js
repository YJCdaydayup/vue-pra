import {AppStackNavigator} from './navigators/AppNavigators'

export default AppStackNavigator;