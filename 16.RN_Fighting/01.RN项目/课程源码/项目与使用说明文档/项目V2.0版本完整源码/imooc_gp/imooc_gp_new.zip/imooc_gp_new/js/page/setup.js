import React from 'react'
import AppNavigator from '../navigators/AppNavigator'

function setup() {
    //在这里可以进行一些初始化配置
    return AppNavigator;
}
module.exports = setup();